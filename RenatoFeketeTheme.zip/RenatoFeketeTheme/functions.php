<?php
require get_template_directory() . '/inc/rf_theme_setup.php';
require get_template_directory() . '/inc/rf_theme_scripts.php';
