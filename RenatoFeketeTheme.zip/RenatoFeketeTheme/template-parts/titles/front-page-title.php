<h1 class="frontpage__title">Hi! My name is Renato and this is my home on the internet.</h1>
<a href="<?php echo site_url('/about-me') ?>" class="frontpage__link">See more</a>