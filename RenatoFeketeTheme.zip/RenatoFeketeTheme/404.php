<?php
get_header();
?>
NEMERE
<?php
get_footer();
?>